/*
 * Auction House
 * Copyright 2023 Kiran Hart
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package ca.tweetzy.auctionhouse.guis;

import ca.tweetzy.auctionhouse.AuctionHouse;
import ca.tweetzy.auctionhouse.managers.SoundManager;
import ca.tweetzy.auctionhouse.settings.Settings;
import ca.tweetzy.flight.comp.enums.CompSound;
import ca.tweetzy.flight.gui.Gui;
import ca.tweetzy.flight.gui.events.GuiClickEvent;
import ca.tweetzy.flight.gui.template.BaseGUI;
import ca.tweetzy.flight.hooks.PlaceholderAPIHook;
import ca.tweetzy.flight.utils.QuickItem;
import lombok.Getter;
import lombok.NonNull;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public abstract class AuctionUpdatingPagedGUI<T> extends BaseGUI {

	@Getter
	protected final Player player;
	protected final Gui parent;
	protected List<T> items;
	protected final int updateDelay;
	protected BukkitTask task;

	public AuctionUpdatingPagedGUI(final Gui parent, @NonNull final Player player, @NonNull final String title, final int rows, int updateDelay, @NonNull final List<T> items) {
		super(parent, PlaceholderAPIHook.tryReplace(player, title), rows);
		this.parent = parent;
		this.player = player;
		// Only wrap in ArrayList if it's not already a mutable list
		this.items = (items instanceof ArrayList) ? items : new ArrayList<>(items);
		this.updateDelay = updateDelay;
		applyDefaults();
	}

	public AuctionUpdatingPagedGUI(@NonNull final Player player, @NonNull final String title, final int rows, int updateDelay, @NonNull final List<T> items) {
		this(null, player, title, rows, updateDelay, items);
		applyDefaults();
	}

	@Override
	protected void draw() {
		// Preserve page number before reset (reset() sets page = 1)

		int currentPage = this.page;
		reset();
		// Restore page number after reset
		this.page = currentPage;
		// Set up page change handler synchronously before async operations
		setOnPage(e -> {
			draw();
			SoundManager.getInstance().playSound(player, Settings.SOUNDS_NAVIGATE_GUI_PAGES.getString());
		});
		populateItems();
		drawFixed();
	}

	protected void startTask() {
		// Cancel any existing task first (safety measure)
		if (this.task != null && !this.task.isCancelled()) {
			this.task.cancel();
			if (AuctionHouse.isDebugMode()) {
				AuctionHouse.getInstance().getLogger().warning("[AuctionUpdatingPagedGUI] Cancelled existing task before starting new one for " + this.getClass().getSimpleName() + " (player: " + this.player.getName() + ")");
			}
		}
		
		this.task = Bukkit.getServer().getScheduler().runTaskTimerAsynchronously(AuctionHouse.getInstance(), () -> {
//			this.fillSlots().forEach(slot -> setItem(slot, getDefaultItem()));
			 draw();
		}, 0L, updateDelay);
		
		// Debug logging
		if (AuctionHouse.isDebugMode()) {
			AuctionHouse.getInstance().getLogger().info("[AuctionUpdatingPagedGUI] Started update task for " + this.getClass().getSimpleName() + " (player: " + this.player.getName() + ", task ID: " + this.task.getTaskId() + ", delay: " + this.updateDelay + " ticks)");
		}
	}

	protected void applyClose() {
		setOnClose(close -> {
			// Debug logging
			if (AuctionHouse.isDebugMode()) {
				AuctionHouse.getInstance().getLogger().info("[AuctionUpdatingPagedGUI] setOnClose triggered for " + this.getClass().getSimpleName() + " (player: " + close.player.getName() + ")");
			}
			cancelTask();
		});
	}

	protected void prePopulate() {
	}


	protected void drawFixed() {
	}

	protected void cancelTask() {
		if (this.task != null && !this.task.isCancelled()) {
			int taskId = this.task.getTaskId();
			this.task.cancel();
			this.task = null; // Clear reference to prevent memory leaks
			// Debug logging
			if (AuctionHouse.isDebugMode()) {
				AuctionHouse.getInstance().getLogger().info("[AuctionUpdatingPagedGUI] Cancelled update task for " + this.getClass().getSimpleName() + " (player: " + this.player.getName() + ", task ID: " + taskId + ")");
			}
		} else if (this.task != null) {
			// Task was already cancelled, but reference still exists - clear it
			this.task = null;
			if (AuctionHouse.isDebugMode()) {
				AuctionHouse.getInstance().getLogger().warning("[AuctionUpdatingPagedGUI] Task was already cancelled but reference still exists for " + this.getClass().getSimpleName() + " (player: " + this.player.getName() + ") - cleared reference");
			}
		}
	}

	/**
	 * Safely transitions from this updating GUI to a new GUI.
	 * This method handles:
	 * - Canceling the update task
	 * - Setting the transition flag to prevent setOnClose from running
	 * - Properly showing the new GUI
	 * 
	 * @param manager The GuiManager instance
	 * @param newGui The new GUI to transition to
	 */
	protected void safeTransitionTo(@NonNull ca.tweetzy.flight.gui.GuiManager manager, @NonNull ca.tweetzy.flight.gui.Gui newGui) {
		// Cancel the update task before transitioning
		this.cancelTask();
		
		// Use the transition method which handles the flag automatically
		this.transitionTo(manager, this.player, newGui);
	}

	private void populateItems() {
		if (this.items != null) {
			// Do all heavy work async, then update GUI on main thread
			AuctionHouse.newChain().asyncFirst(() -> {
				for (int i = 0; i < this.getRows() * 9; i++) {
					setItem(i, getDefaultItem());
				}

				// Heavy operations on async thread:
				// - prePopulate() might do filtering/sorting
				// - Stream operations for pagination
				prePopulate();
				final List<T> paginatedItems = this.items.stream().skip((page - 1) * (long) this.fillSlots().size()).limit(this.fillSlots().size()).collect(Collectors.toCollection(ArrayList::new));
				
				// Build ItemStacks asynchronously (heavy work: string processing, lore building)
				final Map<Integer, ItemStack> slotToItemStack = new HashMap<>();
				final Map<Integer, T> slotToObject = new HashMap<>();
				
				for (int i = 0; i < this.rows * 9; i++) {
					if (this.fillSlots().contains(i) && this.fillSlots().indexOf(i) < paginatedItems.size()) {
						final T object = paginatedItems.get(this.fillSlots().indexOf(i));
						if (object != null) {
							ItemStack displayItem = this.makeDisplayItem(object);
							if (displayItem != null) {
								slotToItemStack.put(i, displayItem);
								slotToObject.put(i, object);
							}
						}
					}
				}
				
				// Return both maps as a pair
				return new Object[] { slotToItemStack, slotToObject };
			}).asyncLast((result) -> {
				@SuppressWarnings("unchecked")
				final Map<Integer, ItemStack> slotToItemStack = (Map<Integer, ItemStack>) ((Object[]) result)[0];
				@SuppressWarnings("unchecked")
				final Map<Integer, T> slotToObject = (Map<Integer, T>) ((Object[]) result)[1];
				
				// All GUI operations on main thread (required for Bukkit API)
				// Calculate pages
				pages = (int) Math.max(1, Math.ceil(this.items.size() / (double) this.fillSlots().size()));
				
				// Clear fill slots & set bg
	
				this.fillSlots().forEach(slot -> setItem(slot, getEmptyFillSlotItem()));

				// Set up navigation buttons
				// Only show previous button if not on first page
				if (this.page > 1) {
					setButton(getPreviousButtonSlot(), getPreviousButton(), click -> {
						prevPage();
						draw();
					});
				} else {
					// Lock slot and remove click handlers when button is hidden
					setUnlocked(getPreviousButtonSlot(), false);
					setConditional(getPreviousButtonSlot(), null, null);
					setItem(getPreviousButtonSlot(), getDefaultItem());
				}
				
				// Only show next button if not on last page
				if (this.page < pages) {
					setButton(getNextButtonSlot(), getNextButton(), click -> {
						nextPage();
						draw();
					});
				} else {
					// Lock slot and remove click handlers when button is hidden
					setUnlocked(getNextButtonSlot(), false);
					setConditional(getNextButtonSlot(), null, null);
					setItem(getNextButtonSlot(), getDefaultItem());
				}

				// Set items for current page using pre-built ItemStacks
				for (Map.Entry<Integer, ItemStack> entry : slotToItemStack.entrySet()) {
					final int slot = entry.getKey();
					final ItemStack itemStack = entry.getValue();
					final T object = slotToObject.get(slot);
					setButton(slot, itemStack, click -> this.onClick(object, click));
				}
			}).execute();
		}
	}

	protected ItemStack getEmptyFillSlotItem() {
		return getDefaultItem();
	}

	protected abstract ItemStack makeDisplayItem(final T object);

	protected abstract void onClick(final T object, final GuiClickEvent clickEvent);

	@Override
	protected ItemStack getBackButton() {
		return QuickItem
				.of(Settings.GUI_BACK_BTN_ITEM.getString())
				.name(Settings.GUI_BACK_BTN_NAME.getString())
				.lore(this.player, Settings.GUI_BACK_BTN_LORE.getStringList())
				.make();
	}

	@Override
	protected ItemStack getExitButton() {
		return QuickItem
				.of(Settings.GUI_CLOSE_BTN_ITEM.getString())
				.name(Settings.GUI_CLOSE_BTN_NAME.getString())
				.lore(this.player, Settings.GUI_CLOSE_BTN_LORE.getStringList())
				.make();
	}

	@Override
	protected ItemStack getPreviousButton() {
		return QuickItem
				.of(Settings.GUI_PREV_PAGE_BTN_ITEM.getString())
				.name(Settings.GUI_PREV_PAGE_BTN_NAME.getString())
				.lore(this.player, Settings.GUI_PREV_PAGE_BTN_LORE.getStringList())
				.make();
	}

	@Override
	protected ItemStack getNextButton() {
		return QuickItem
				.of(Settings.GUI_NEXT_PAGE_BTN_ITEM.getString())
				.name(Settings.GUI_NEXT_PAGE_BTN_NAME.getString())
				.lore(this.player, Settings.GUI_NEXT_PAGE_BTN_LORE.getStringList())
				.make();
	}

	protected ItemStack getRefreshButton() {
		return QuickItem
				.of(Settings.GUI_REFRESH_BTN_ITEM.getString())
				.name(Settings.GUI_REFRESH_BTN_NAME.getString())
				.lore(Settings.GUI_REFRESH_BTN_LORE.getStringList())
				.make();
	}

	private void applyDefaults() {
		setDefaultItem(QuickItem.bg(QuickItem.of(Settings.GUI_FILLER.getString()).make()));
		setNavigateSound(CompSound.matchCompSound(Settings.SOUNDS_NAVIGATE_GUI_PAGES.getString()).orElse(CompSound.ENTITY_BAT_TAKEOFF));
		setDefaultSound(CompSound.matchCompSound(Settings.SOUNDS_GUI_CLICK.getString()).orElse(CompSound.UI_BUTTON_CLICK));
	}

	@Override
	protected int getPreviousButtonSlot() {
		return 48;
	}

	@Override
	protected int getNextButtonSlot() {
		return 50;
	}
}