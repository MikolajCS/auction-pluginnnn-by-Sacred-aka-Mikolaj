/*
 * Auction House
 * Copyright 2023 Kiran Hart
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package ca.tweetzy.auctionhouse.api.sync;

public interface Navigable<E extends Enum<E>> {

	default E next() {
		E[] values = enumClass().getEnumConstants();
		E current = (E) this;
		int ordinal = current.ordinal();
		int nextOrdinal = (ordinal + 1) % values.length;
		return values[nextOrdinal];
	}

	default E previous() {
		E[] values = enumClass().getEnumConstants();
		E current = (E) this;
		int ordinal = current.ordinal();
		int previousOrdinal = (ordinal - 1 + values.length) % values.length;
		return values[previousOrdinal];
	}

	Class<E> enumClass();
}