/*
 * Auction House
 * Copyright 2018-2022 Kiran Hart
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package ca.tweetzy.auctionhouse.guis.confirmation;

import ca.tweetzy.auctionhouse.AuctionHouse;
import ca.tweetzy.auctionhouse.api.AuctionAPI;
import ca.tweetzy.auctionhouse.api.event.AuctionRequestCompleteEvent;
import ca.tweetzy.auctionhouse.auction.AuctionPayment;
import ca.tweetzy.auctionhouse.auction.AuctionPlayer;
import ca.tweetzy.auctionhouse.auction.AuctionedItem;
import ca.tweetzy.auctionhouse.auction.enums.AuctionSaleType;
import ca.tweetzy.auctionhouse.auction.enums.AuctionStackType;
import ca.tweetzy.auctionhouse.auction.enums.PaymentReason;
import ca.tweetzy.auctionhouse.events.AuctionEndEvent;
import ca.tweetzy.auctionhouse.exception.ItemNotFoundException;
import ca.tweetzy.auctionhouse.guis.AuctionBaseGUI;
import ca.tweetzy.auctionhouse.guis.core.GUIAuctionHouse;
import ca.tweetzy.auctionhouse.guis.core.GUIContainerInspect;
import ca.tweetzy.auctionhouse.impl.CompletedRequest;
import ca.tweetzy.auctionhouse.managers.SoundManager;
import ca.tweetzy.auctionhouse.settings.Settings;
import ca.tweetzy.core.utils.PlayerUtils;
import ca.tweetzy.flight.gui.events.GuiClickEvent;
import ca.tweetzy.flight.nbtapi.NBT;
import ca.tweetzy.flight.utils.QuickItem;
import ca.tweetzy.flight.utils.Replacer;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.ShulkerBox;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * The current file has been created by Kiran Hart
 * Date Created: March 17 2021
 * Time Created: 11:18 p.m.
 * Usage of any code found within this class is prohibited unless given explicit permission otherwise
 */
public class GUIConfirmPurchase extends AuctionBaseGUI {

	final AuctionPlayer auctionPlayer;
	final AuctionedItem auctionItem;

	boolean buyingSpecificQuantity;
	int purchaseQuantity = 0;
	int maxStackSize = 0;
	double pricePerItem = 0D;

	public GUIConfirmPurchase(AuctionPlayer auctionPlayer, AuctionedItem auctionItem, boolean buyingSpecificQuantity) {
		super(null, auctionPlayer.getPlayer(), Settings.GUI_CONFIRM_BUY_TITLE.getString(), !buyingSpecificQuantity ? 1 : 5);
		this.auctionPlayer = auctionPlayer;
		this.auctionItem = auctionItem;
		this.buyingSpecificQuantity = buyingSpecificQuantity;
		setAcceptsItems(false);

		int preAmount = auctionItem.getItem().getAmount();
		if (preAmount == 1) {
			this.buyingSpecificQuantity = false;
		}

		if (this.buyingSpecificQuantity) {
			setUseLockedCells(Settings.GUI_CONFIRM_FILL_BG_ON_QUANTITY.getBoolean());
			setDefaultItem(QuickItem.bg(QuickItem.of(Settings.GUI_CONFIRM_BG_ITEM.getString()).make()));
			this.purchaseQuantity = preAmount;
			this.maxStackSize = preAmount;
			this.pricePerItem = this.auctionItem.getBasePrice() / this.maxStackSize;
		}

		setOnOpen(open -> AuctionHouse.getInstance().getLogger().info("Added " + open.player.getName() + " to confirmation pre purchase"));

		setOnClose(close -> {
			AuctionHouse.getTransactionManager().getPrePurchaseHolding().remove(close.player);
			close.manager.showGUI(close.player, new GUIAuctionHouse(this.auctionPlayer));
			AuctionHouse.getInstance().getLogger().info("Removed " + close.player.getName() + " from confirmation pre purchase");
		});

		draw();
	}

	/**
	 * Processes a purchase without showing the confirmation GUI.
	 * This method contains all the purchase logic extracted from the confirmation GUI.
	 *
	 * @param player The player making the purchase
	 * @param auctionPlayer The auction player instance
	 * @param auctionItem The item being purchased
	 * @param buyingSpecificQuantity Whether purchasing a specific quantity
	 * @param purchaseQuantity The quantity to purchase (only used if buyingSpecificQuantity is true)
	 * @param pricePerItem The price per item (only used if buyingSpecificQuantity is true)
	 * @return true if the purchase was successful, false otherwise
	 */
	public static boolean processPurchase(Player player, AuctionPlayer auctionPlayer, AuctionedItem auctionItem, boolean buyingSpecificQuantity, int purchaseQuantity, double pricePerItem) {
		try {
			// if the item is in the garbage then just don't continue
			if (AuctionHouse.getAuctionItemManager().getGarbageBin().containsKey(auctionItem.getId()))
				return false;

			AuctionedItem located = AuctionHouse.getAuctionItemManager().getItem(auctionItem.getId());

			if (located == null || located.isExpired()) {
				AuctionHouse.getInstance().getLocale().getMessage("auction.itemnotavailable").sendPrefixedMessage(player);
				return false;
			}

			// Determine if this purchase will fully consume the item
			boolean willFullyConsume = !buyingSpecificQuantity ||
				(located.getItem().getAmount() - purchaseQuantity < 1) ||
				located.isInfinite();

			double buyNowPrice = buyingSpecificQuantity ? purchaseQuantity * pricePerItem : located.getBasePrice();
			double tax = Settings.TAX_ENABLED.getBoolean() ? (Settings.TAX_SALES_TAX_BUY_NOW_PERCENTAGE.getDouble() / 100) * buyNowPrice : 0D;
			final boolean isRequest = auctionItem.isRequest();

			/*
			============================================================================
									SPECIAL SHIT FOR REQUESTS
			============================================================================
			 */
			if (isRequest) {
				//todo add multi currency support to requests
				// check if the fulfiller even has the item
				final int itemCount = AuctionAPI.getInstance().getItemCountInPlayerInventory(player, auctionItem.getItem());
				final int amountNeeded = auctionItem.getRequestAmount() == 0 ? auctionItem.getItem().getAmount() : auctionItem.getRequestAmount();

				if (itemCount < amountNeeded) {
					// yell at fulfiller for being dumb
					AuctionHouse.getInstance().getLocale().getMessage("general.notenoughitems").sendPrefixedMessage(player);
					return false;
				}

				final OfflinePlayer requester = Bukkit.getOfflinePlayer(auctionItem.getOwner());

				// check if the requester even has money
				if (!AuctionHouse.getCurrencyManager().has(requester, buyNowPrice)) {
					AuctionHouse.getInstance().getLocale().getMessage("general.requesterhasnomoney").sendPrefixedMessage(player);
					return false;
				}

				// transfer funds
				AuctionHouse.getCurrencyManager().withdraw(requester, buyNowPrice);
				AuctionHouse.getCurrencyManager().deposit(player, Settings.TAX_CHARGE_SALES_TAX_TO_BUYER.getBoolean() ? buyNowPrice : buyNowPrice - tax);

				// transfer items
				AuctionAPI.getInstance().removeSpecificItemQuantityFromPlayer(player, auctionItem.getItem(), amountNeeded);
				final AuctionedItem toGive = new AuctionedItem(
						UUID.randomUUID(),
						requester.getUniqueId(),
						requester.getUniqueId(),
						auctionItem.getOwnerName(),
						auctionItem.getOwnerName(),
						auctionItem.getCategory(),
						auctionItem.getItem(),
						0,
						0,
						0,
						0,
						false, true, System.currentTimeMillis()
				);

				toGive.setRequestAmount(amountNeeded);
				toGive.setRequest(true);
				toGive.setCreatedAt(System.currentTimeMillis());

				AuctionHouse.getDataManager().insertAuction(toGive, (error, inserted) -> AuctionHouse.getAuctionItemManager().addAuctionItem(toGive));

				// Item already marked as purchased above (race condition protection)

				AuctionHouse.getTransactionManager().getPrePurchasePlayers(auctionItem.getId()).forEach(p -> {
					AuctionHouse.getTransactionManager().removeAllRelatedPlayers(auctionItem.getId());
					p.closeInventory();
				});

				AuctionHouse.getInstance().getLocale().getMessage("pricing.moneyadd")
						.processPlaceholder("player_balance", AuctionHouse.getAPI().getFinalizedCurrencyNumber(AuctionHouse.getCurrencyManager().getBalance(player, auctionItem.getCurrency().split("/")[0], auctionItem.getCurrency().split("/")[1]), auctionItem.getCurrency(), auctionItem.getCurrencyItem()))
						.processPlaceholder("price", auctionItem.getFormattedBasePrice())
						.sendPrefixedMessage(player);

				if (requester.isOnline())
					AuctionHouse.getInstance().getLocale().getMessage("pricing.moneyremove")
							.processPlaceholder("player_balance", AuctionHouse.getAPI().getFinalizedCurrencyNumber(AuctionHouse.getCurrencyManager().getBalance(requester, auctionItem.getCurrency().split("/")[0], auctionItem.getCurrency().split("/")[1]), auctionItem.getCurrency(), auctionItem.getCurrencyItem()))
							.processPlaceholder("price", auctionItem.getFormattedBasePrice())
							.sendPrefixedMessage(requester.getPlayer());

				final AuctionRequestCompleteEvent requestCompleteEvent = new AuctionRequestCompleteEvent(auctionItem, new CompletedRequest(auctionItem, player, Settings.TAX_CHARGE_SALES_TAX_TO_BUYER.getBoolean() ? buyNowPrice : buyNowPrice - tax));
				Bukkit.getServer().getPluginManager().callEvent(requestCompleteEvent);

				return true;
			}

			// Check economy
			if (!auctionItem.playerHasSufficientMoney(player, buyNowPrice + (Settings.TAX_CHARGE_SALES_TAX_TO_BUYER.getBoolean() ? tax : 0D))) {
				AuctionHouse.getInstance().getLocale().getMessage("general.notenoughmoney").sendPrefixedMessage(player);
				SoundManager.getInstance().playSound(player, Settings.SOUNDS_NOT_ENOUGH_MONEY.getString());
				return false;
			}

			// Check inventory space BEFORE marking as purchased to prevent item deletion
			if (!Settings.ALLOW_PURCHASE_IF_INVENTORY_FULL.getBoolean() && player.getInventory().firstEmpty() == -1) {
				AuctionHouse.getInstance().getLocale().getMessage("general.noroom").sendPrefixedMessage(player);
				SoundManager.getInstance().playSound(player, Settings.SOUNDS_NOT_ENOUGH_MONEY.getString());
				return false;
			}

			// CRITICAL: Atomically mark item as purchased AFTER all validation checks to prevent race conditions
			// Only mark if the item will be fully consumed (for partial purchases, multiple buyers are allowed)
			// If another player already purchased it, this will return false and we'll exit early
			if (willFullyConsume && !located.isInfinite()) {
				if (!AuctionHouse.getAuctionItemManager().tryMarkAsPurchased(located)) {
					AuctionHouse.getInstance().getLocale().getMessage("auction.itemnotavailable").sendPrefixedMessage(player);
					return false;
				}
			}

			AuctionEndEvent auctionEndEvent = new AuctionEndEvent(Bukkit.getOfflinePlayer(auctionItem.getOwner()), player, auctionItem, AuctionSaleType.WITHOUT_BIDDING_SYSTEM, tax, false);
			Bukkit.getServer().getPluginManager().callEvent(auctionEndEvent);
			if (auctionEndEvent.isCancelled()) {
				AuctionHouse.getInstance().getLocale().getMessage("general.cancelled").sendPrefixedMessage(player);
				return false;
			}

			ItemStack deserializeItem = auctionItem.getItem().clone();

			if (buyingSpecificQuantity) {
				// the original item stack
				ItemStack item = auctionItem.getItem().clone();
				ItemStack toGive = auctionItem.getItem().clone();

				if (item.getAmount() - purchaseQuantity >= 1 && !located.isInfinite()) {
					item.setAmount(item.getAmount() - purchaseQuantity);
					toGive.setAmount(purchaseQuantity);

					located.setItem(item);
					located.setBasePrice(Settings.ROUND_ALL_PRICES.getBoolean() ? Math.round(located.getBasePrice() - buyNowPrice) : located.getBasePrice() - buyNowPrice);

					transferFundsStatic(player, buyNowPrice, auctionItem);
				} else {
					transferFundsStatic(player, buyNowPrice, auctionItem);
					// Item already marked as purchased above (race condition protection) - no need to sendToGarbage again
				}

				NBT.modify(toGive, nbt -> {
					nbt.removeKey("AuctionDupeTracking");
				});

				PlayerUtils.giveItem(player, toGive);
				sendMessagesStatic(player, located, true, buyNowPrice, purchaseQuantity, auctionItem);

			} else {
				transferFundsStatic(player, buyNowPrice, auctionItem);
				// Item already marked as purchased above (race condition protection) - no need to sendToGarbage again

				if (Settings.BIDDING_TAKES_MONEY.getBoolean() && !located.getHighestBidder().equals(located.getOwner())) {
					final OfflinePlayer oldBidder = Bukkit.getOfflinePlayer(located.getHighestBidder());

					if (Settings.STORE_PAYMENTS_FOR_MANUAL_COLLECTION.getBoolean())
						AuctionHouse.getDataManager().insertAuctionPayment(new AuctionPayment(
								oldBidder.getUniqueId(),
								auctionItem.getCurrentPrice(),
								auctionItem.getItem(),
								AuctionHouse.getInstance().getLocale().getMessage("general.prefix").getMessage(),
								PaymentReason.BID_RETURNED,
								auctionItem.getCurrency(),
								auctionItem.getCurrencyItem()
						), null);
					else
						AuctionHouse.getCurrencyManager().deposit(oldBidder, auctionItem.getCurrentPrice(), auctionItem.getCurrency(), auctionItem.getCurrencyItem());

					String[] currencyParts = auctionItem.getCurrency().split("/");
					String currencyPlugin = currencyParts.length > 0 ? currencyParts[0] : "Vault";
					String currencyName = currencyParts.length > 1 ? currencyParts[1] : "Vault";
					String balanceStr = AuctionHouse.getAPI().getFinalizedCurrencyNumber(AuctionHouse.getCurrencyManager().getBalance(oldBidder, currencyPlugin, currencyName), auctionItem.getCurrency(), auctionItem.getCurrencyItem());
					String priceStr = located.getFormattedCurrentPrice();
					if (oldBidder.isOnline() && oldBidder.getName() != null) {
						AuctionHouse.getInstance().getLocale().getMessage("pricing.moneyadd")
								.processPlaceholder("player_balance", balanceStr)
								.processPlaceholder("price", priceStr)
								.sendPrefixedMessage(oldBidder.getPlayer());
					} else {
						HashMap<String, String> placeholders = new HashMap<>();
						placeholders.put("player_balance", balanceStr);
						placeholders.put("price", priceStr);
						AuctionHouse.getNotificationManager().queue(oldBidder.getUniqueId(), "pricing.moneyadd", placeholders);
					}
				}

				ItemStack foundItem = located.getItem().clone();

				NBT.modify(foundItem, nbt -> {
					nbt.removeKey("AuctionDupeTracking");
				});

				PlayerUtils.giveItem(player, foundItem);

				sendMessagesStatic(player, located, false, 0, deserializeItem.getAmount(), auctionItem);
			}

			if (Settings.BROADCAST_AUCTION_SALE.getBoolean()) {
				final OfflinePlayer seller = Bukkit.getOfflinePlayer(auctionItem.getOwner());

				Bukkit.getOnlinePlayers().forEach(p -> AuctionHouse.getInstance().getLocale().getMessage("auction.broadcast.sold")
						.processPlaceholder("player", player.getName())
						.processPlaceholder("player_displayname", AuctionAPI.getInstance().getDisplayName(player))
						.processPlaceholder("seller", auctionItem.getOwnerName())
						.processPlaceholder("seller_displayname", AuctionAPI.getInstance().getDisplayName(seller))
						.processPlaceholder("amount", auctionItem.getItem().getAmount())
						.processPlaceholder("item", AuctionAPI.getInstance().getItemName(auctionItem.getItem()))
						.processPlaceholder("price",
								auctionItem.getBasePrice() > auctionItem.getCurrentPrice() ? auctionItem.getFormattedBasePrice() : auctionItem.getFormattedCurrentPrice()
						)
						.sendPrefixedMessage(p));
			}

			AuctionHouse.getTransactionManager().getPrePurchasePlayers(auctionItem.getId()).forEach(p -> {
				AuctionHouse.getTransactionManager().removeAllRelatedPlayers(auctionItem.getId());
				p.closeInventory();
			});

			return true;

		} catch (ItemNotFoundException exception) {
			AuctionHouse.getInstance().getLogger().info("Tried to purchase item that was bought, or does not exist");
			AuctionHouse.getInstance().getLocale().getMessage("auction.itemnotavailable").sendPrefixedMessage(player);
			return false;
		} catch (Exception exception) {
			AuctionHouse.getInstance().getLogger().severe("Error processing purchase: " + exception.getMessage());
			exception.printStackTrace();
			AuctionHouse.getInstance().getLocale().getMessage("general.error").sendPrefixedMessage(player);
			return false;
		}
	}

	private static void transferFundsStatic(Player from, double amount, AuctionedItem auctionItem) {
		double tax = Settings.TAX_ENABLED.getBoolean() ? (Settings.TAX_SALES_TAX_BUY_NOW_PERCENTAGE.getDouble() / 100) * amount : 0D;

		AuctionAPI.getInstance().withdrawBalance(from, Settings.ROUND_ALL_PRICES.getBoolean() ? Math.round(Settings.TAX_CHARGE_SALES_TAX_TO_BUYER.getBoolean() ? amount + tax : amount) : Settings.TAX_CHARGE_SALES_TAX_TO_BUYER.getBoolean() ? amount + tax : amount, auctionItem);
		AuctionAPI.getInstance().depositBalance(Bukkit.getOfflinePlayer(auctionItem.getOwner()), Settings.ROUND_ALL_PRICES.getBoolean() ? Math.round(Settings.TAX_CHARGE_SALES_TAX_TO_BUYER.getBoolean() ? amount : amount - tax) : Settings.TAX_CHARGE_SALES_TAX_TO_BUYER.getBoolean() ? amount : amount - tax, auctionItem.getItem(), from, auctionItem);
	}

	private static void sendMessagesStatic(Player player, AuctionedItem located, boolean overwritePrice, double price, int qtyOverride, AuctionedItem auctionItem) {
		double totalPrice = overwritePrice ? price : located.getBasePrice();
		double tax = Settings.TAX_ENABLED.getBoolean() ? (Settings.TAX_SALES_TAX_BUY_NOW_PERCENTAGE.getDouble() / 100) * totalPrice : 0D;

		AuctionHouse.getInstance().getLocale().getMessage("pricing.moneyremove")
				.processPlaceholder("player_balance", AuctionHouse.getAPI().getFinalizedCurrencyNumber(AuctionHouse.getCurrencyManager().getBalance(player, auctionItem.getCurrency().split("/")[0], auctionItem.getCurrency().split("/")[1]), auctionItem.getCurrency(), auctionItem.getCurrencyItem()))
				.processPlaceholder("price", AuctionHouse.getAPI().getFinalizedCurrencyNumber(Settings.TAX_CHARGE_SALES_TAX_TO_BUYER.getBoolean() ? totalPrice - tax : totalPrice, auctionItem.getCurrency(), auctionItem.getCurrencyItem()))
				.sendPrefixedMessage(player);

		AuctionHouse.getInstance().getLocale().getMessage("general.bought_item")
				.processPlaceholder("amount", qtyOverride).processPlaceholder("item", AuctionAPI.getInstance().getItemName(located.getItem()))
				.processPlaceholder("price", AuctionHouse.getAPI().getFinalizedCurrencyNumber(Settings.TAX_CHARGE_SALES_TAX_TO_BUYER.getBoolean() ? totalPrice - tax : totalPrice, auctionItem.getCurrency(), auctionItem.getCurrencyItem()))
				.sendPrefixedMessage(player);

		OfflinePlayer seller = Bukkit.getOfflinePlayer(located.getOwner());
		String itemName = AuctionAPI.getInstance().getItemName(located.getItem());
		String priceFormatted = AuctionHouse.getAPI().getFinalizedCurrencyNumber(Settings.TAX_CHARGE_SALES_TAX_TO_BUYER.getBoolean() ? totalPrice : totalPrice - tax, auctionItem.getCurrency(), auctionItem.getCurrencyItem());
		String[] currencyParts = auctionItem.getCurrency().split("/");
		String currencyPlugin = currencyParts.length > 0 ? currencyParts[0] : "Vault";
		String currencyName = currencyParts.length > 1 ? currencyParts[1] : "Vault";
		String sellerBalanceStr = AuctionHouse.getAPI().getFinalizedCurrencyNumber(AuctionHouse.getCurrencyManager().getBalance(seller, currencyPlugin, currencyName), auctionItem.getCurrency(), auctionItem.getCurrencyItem());

		if (seller.isOnline() && seller.getPlayer() != null) {
			AuctionHouse.getInstance().getLocale().getMessage("auction.itemsold")
					.processPlaceholder("item", itemName)
					.processPlaceholder("amount", String.valueOf(qtyOverride))
					.processPlaceholder("price", priceFormatted)
					.processPlaceholder("buyer_name", player.getName())
					.sendPrefixedMessage(seller.getPlayer());

			AuctionHouse.getInstance().getLocale().getMessage("pricing.moneyadd")
					.processPlaceholder("player_balance", sellerBalanceStr)
					.processPlaceholder("price", priceFormatted)
					.sendPrefixedMessage(seller.getPlayer());

			SoundManager.getInstance().playSound(seller.getPlayer(), Settings.SOUNDS_ITEM_SOLD.getString());
		} else {
			Map<String, String> itemsoldPlaceholders = new HashMap<>();
			itemsoldPlaceholders.put("item", itemName);
			itemsoldPlaceholders.put("amount", String.valueOf(qtyOverride));
			itemsoldPlaceholders.put("price", priceFormatted);
			itemsoldPlaceholders.put("buyer_name", player.getName());
			AuctionHouse.getNotificationManager().queue(seller.getUniqueId(), "auction.itemsold", itemsoldPlaceholders);

			Map<String, String> moneyaddPlaceholders = new HashMap<>();
			moneyaddPlaceholders.put("player_balance", sellerBalanceStr);
			moneyaddPlaceholders.put("price", priceFormatted);
			AuctionHouse.getNotificationManager().queue(seller.getUniqueId(), "pricing.moneyadd", moneyaddPlaceholders);
		}
	}

	@Override
	protected void draw() {
		ItemStack deserializeItem = this.auctionItem.getItem().clone();
		final boolean isRequest = this.auctionItem.isRequest();

		setItems(this.buyingSpecificQuantity ? 9 : 0, this.buyingSpecificQuantity ? 12 : 3, isRequest ? getConfirmRequestYesItem() : getConfirmBuyYesItem());
		setItem(this.buyingSpecificQuantity ? 1 : 0, 4, isRequest ? this.auctionItem.getDisplayRequestStack(this.player, AuctionStackType.MAIN_AUCTION_HOUSE) : this.auctionItem.getDisplayStack(this.player, AuctionStackType.LISTING_PREVIEW));
		setItems(this.buyingSpecificQuantity ? 14 : 5, this.buyingSpecificQuantity ? 17 : 8, isRequest ? getConfirmRequestNoItem() : getConfirmBuyNoItem());

		setAction(this.buyingSpecificQuantity ? 1 : 0, 4, ClickType.LEFT, e -> {
			if (deserializeItem.getItemMeta() instanceof BlockStateMeta) {
				if (((BlockStateMeta) deserializeItem.getItemMeta()).getBlockState() instanceof ShulkerBox) {
					AuctionHouse.getTransactionManager().getPrePurchaseHolding().remove(e.player);
					this.safeTransitionTo(e.manager, new GUIContainerInspect(e.clickedItem, this.auctionPlayer, this.auctionItem, this.buyingSpecificQuantity));
				}
			}
		});

		setActionForRange(this.buyingSpecificQuantity ? 14 : 5, this.buyingSpecificQuantity ? 17 : 8, ClickType.LEFT, e -> {
			e.gui.close();
		});

		setActionForRange(this.buyingSpecificQuantity ? 9 : 0, this.buyingSpecificQuantity ? 12 : 3, ClickType.LEFT, e -> {
			boolean success = processPurchase(e.player, this.auctionPlayer, this.auctionItem, this.buyingSpecificQuantity, this.purchaseQuantity, this.pricePerItem);
			if (success) {
				SoundManager.getInstance().playSound(e.player, Settings.SOUNDS_PURCHASE_SUCCESS.getString());
				this.safeTransitionTo(e.manager, new GUIAuctionHouse(this.auctionPlayer));
			} else {
				this.safeTransitionTo(e.manager, new GUIAuctionHouse(this.auctionPlayer));
			}
		});

		if (this.buyingSpecificQuantity) {
			drawPurchaseInfo(this.maxStackSize);

			// Decrease Button
			setButton(3, 3, getDecreaseQtyButtonItem(), e -> {
				if ((this.purchaseQuantity - 1) <= 0) return;
				this.purchaseQuantity -= 1;
				drawPurchaseInfo(this.purchaseQuantity);
			});

			// Increase Button
			setButton(3, 5, getIncreaseQtyButtonItem(), e -> {
				if ((this.purchaseQuantity + 1) > this.maxStackSize) return;
				this.purchaseQuantity += 1;
				drawPurchaseInfo(this.purchaseQuantity);
			});
		}
	}

	private void drawPurchaseInfo(int amt) {
		setItem(3, 4, getPurchaseInfoItem(amt));
	}

	private ItemStack getPurchaseInfoItem(int qty) {
		return QuickItem
				.of(Settings.GUI_CONFIRM_QTY_INFO_ITEM.getString())
				.amount(qty)
				.name(Settings.GUI_CONFIRM_QTY_INFO_NAME.getString())
				.lore(this.player, Replacer.replaceVariables(Settings.GUI_CONFIRM_QTY_INFO_LORE.getStringList(),
						"original_stack_size", maxStackSize,
						"original_stack_price", auctionItem.getFormattedBasePrice(),
						"price_per_item", AuctionHouse.getAPI().getFinalizedCurrencyNumber(pricePerItem, auctionItem.getCurrency(), auctionItem.getCurrencyItem()),
						"purchase_quantity", purchaseQuantity,
						"purchase_price", AuctionHouse.getAPI().getFinalizedCurrencyNumber(pricePerItem * purchaseQuantity, auctionItem.getCurrency(), auctionItem.getCurrencyItem())
				))
				.make();
	}

	private ItemStack getIncreaseQtyButtonItem() {
		return QuickItem.of(Settings.GUI_CONFIRM_INCREASE_QTY_ITEM.getString()).name(Settings.GUI_CONFIRM_INCREASE_QTY_NAME.getString()).lore(this.player, Settings.GUI_CONFIRM_INCREASE_QTY_LORE.getStringList()).make();
	}

	private ItemStack getDecreaseQtyButtonItem() {
		return QuickItem.of(Settings.GUI_CONFIRM_DECREASE_QTY_ITEM.getString()).name(Settings.GUI_CONFIRM_DECREASE_QTY_NAME.getString()).lore(this.player, Settings.GUI_CONFIRM_DECREASE_QTY_LORE.getStringList()).make();
	}

	protected ItemStack getConfirmBuyYesItem() {
		return QuickItem.of(Settings.GUI_CONFIRM_BUY_YES_ITEM.getString()).name(Settings.GUI_CONFIRM_BUY_YES_NAME.getString()).lore(this.player, Settings.GUI_CONFIRM_BUY_YES_LORE.getStringList()).make();
	}

	protected ItemStack getConfirmBuyNoItem() {
		return QuickItem.of(Settings.GUI_CONFIRM_BUY_NO_ITEM.getString()).name(Settings.GUI_CONFIRM_BUY_NO_NAME.getString()).lore(this.player, Settings.GUI_CONFIRM_BUY_NO_LORE.getStringList()).make();
	}

	protected ItemStack getConfirmRequestYesItem() {
		return QuickItem.of(Settings.GUI_CONFIRM_REQUEST_YES_ITEM.getString()).name(Settings.GUI_CONFIRM_REQUEST_YES_NAME.getString()).lore(this.player, Settings.GUI_CONFIRM_REQUEST_YES_LORE.getStringList()).make();
	}

	protected ItemStack getConfirmRequestNoItem() {
		return QuickItem.of(Settings.GUI_CONFIRM_REQUEST_NO_ITEM.getString()).name(Settings.GUI_CONFIRM_REQUEST_NO_NAME.getString()).lore(this.player, Settings.GUI_CONFIRM_REQUEST_NO_LORE.getStringList()).make();
	}
}
